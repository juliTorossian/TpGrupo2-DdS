<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Iniciar Sesion - FERREtian</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- Favicon -->
    <link href="./public/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="./public/lib/animate/animate.min.css" rel="stylesheet">
    <link href="./public/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="./public/css/style.css" rel="stylesheet">
    <link href="./public/css/stylePropio.css" rel="stylesheet">
</head>

<body class="body_login">

    
    <div class="content_login cuadro-login">
        <div class="centrado">
            <img src="./public/img/LogoLogin.png" alt="login image">
            <div class="form_main contact-form">
                <form action="index.php?controller=usuarioCON&action=login" method="POST">
                    <label for="usuNombre">Usuario:</label>
                    <input type="text" name="usuNombre" class="form_camp form-control" required>
                    <label for="usuPass">Contraseña:</label>
                    <input type="password" name="usuPass" class="form_camp form-control" required>
    
                    <input type="submit" name="submit" class="form_submit" value="Iniciar Sesion">

                    
                    <p class="no_cuenta"> No tenes cuenta? <a href="index.php?controller=usuarioCON&action=registrar">Registrate</a></p>
                </form>
            </div>
        </div>
    </div>


</body>

</html>